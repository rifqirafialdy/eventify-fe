export default function AboutPage() {
  return <h1 className="text-2xl font-bold">About Us</h1>
}
