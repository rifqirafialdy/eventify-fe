import RoleSelector from './RoleSelector';

export default function RegisterPage() {
  return <RoleSelector />;
}
